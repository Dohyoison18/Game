#pragma once
class Sounds
{
	public :
	int BGM[6];
	int SE;
	int BGMVolume;
	int SEVolume;
	
	Sounds();

	void PlayTitleSounds();
	void PlayPonkotsuSounds();
	void PlayClearSounds();
	void PlayBadSounds();
	void PlaySearchSounds();
	void PlayThinkingSounds();
	void PlayItemGetSounds();
};