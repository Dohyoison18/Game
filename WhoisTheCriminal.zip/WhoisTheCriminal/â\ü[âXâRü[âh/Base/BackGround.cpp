#include "DxLib.h"
#include "DrawString.h"
#include "BackGround.h"
#include "math.h"

const int WIN_WIDTH = 1600; //�E�B���h�E����
const int WIN_HEIGHT = 900;//�E�B���h�E�c��

#define MenuMax 9
#define MaxVel 200

double easeOutQuint(double x)
{
	return 1 - pow((double)1 - x, 5);
}

double easeOutBounce(double x)
{
	const double n1 = 7.5625;
	const double d1 = 2.75;

	if (x < 1 / d1) {
		return n1 * x * x;
	}
	else if (x < 2 / d1) {
		return n1 * (x -= 1.5 / d1) * x + 0.75;
	}
	else if (x < 2.5 / d1) {
		return n1 * (x -= 2.25 / d1) * x + 0.9375;
	}
	else {
		return n1 * (x -= 2.625 / d1) * x + 0.984375;
	}
}

BackGround::BackGround()
{
	Scene = 0;
	OldScene = Scene;
	CenterX = WIN_WIDTH / 2;
	CenterY = WIN_HEIGHT / 2;
	ItemVel = 0;
	DoDetective = FALSE;
	Detective = FALSE;
	CharaSelectX = 0;
	CharaSelectY = 0;
	HowEnd = 0;
	MeterUpAmount = 0;
	MeterDownAmount = 0;
	MeterUpTimes = 0;
	MeterDownTimes = 0;
	DoMeterUp = FALSE;
	DoMeterDown = FALSE;

	for (int i = 0; i < MenuMax; i++)
	{
		MenuX[i] = 1700;
		MenuY[i] = (i + 1) * 100;
	}
	MenuFlag = FALSE;
	MenuDraw = FALSE;

	FrameColor = GetColor(0x3F, 0x3F, 0x74);
	Gold = GetColor(0xFF, 0xD7, 0x00);
	Silver = GetColor(0xC0, 0xC0, 0xC0);
	White = GetColor(0xF0, 0xF0, 0xF0);
	Chartreuse = GetColor(0x7F, 0xFF, 0x00);
	FrameGr = LoadGraph("Materials/AllUse/Gr/frame.png");
	MouseGr = LoadGraph("Materials/AllUse/Gr/cursor.png");
	TextBox[0] = LoadGraph("Materials/AllUse/Gr/textbox_font32.png");
	TextBox[1] = LoadGraph("Materials/AllUse/Gr/charaName_box.png");
	Mark[0] = LoadGraph("Materials/AllUse/Gr/QuestionMark.png");
	Mark[1] = LoadGraph("Materials/AllUse/Gr/SettingMark.png");
}

void BackGround::EaseIn(BackGround* back)
{
	MenuFrame[0]++;

	for (int i = 0; i < MenuMax; i++)
	{
		if (MenuX[i] <= WIN_WIDTH)
		{
			MenuX[i] = 1520 + (100 * easeOutQuint((double)MenuFrame[0] / MaxFrame));
		}
	}

	MenuFrame[1] = 0;
}

void BackGround::EaseOut(BackGround* back)
{
	MenuFrame[1]++;

	for (int i = 0; i < MenuMax; i++)
	{
		if (MenuX[i] >= 1520)
		{
			MenuX[i] = WIN_WIDTH - (100 * easeOutQuint((double)MenuFrame[1] / MaxFrame));
		}
	}

	MenuFrame[0] = 0;
}

void BackGround::MingTurn(BackGround* back)
{
	if (back->Bright <= 256)
	{
		back->Bright += 2;
	}
}

void BackGround::ZoomUp(BackGround* back)
{
	if (back->ItemVel < MaxVel)
	{
		back->ItemVel += 50;
	}
}

void BackGround::Bound(BackGround* back)
{
	back->SelectFrame++;
	if (back->CharaSelectY <= 0)
	{
		back->CharaSelectY = -800 + (800 * easeOutBounce((double)back->SelectFrame / MaxFrame));
	}
	/*SelectFrame[1] = 0;

	SelectFrame[1]++;
	if (back->CharaSelectY <= 0)
	{
		back->CharaSelectY = (-800 * easeOutBounce((double)SelectFrame[0] / MaxFrame));
	}
	SelectFrame[0] = 0;*/
}

void BackGround::MeterUp(BackGround* back)
{
	if (back->DoMeterUp == TRUE)
	{
		if (back->MeterUpTimes < MeterUpMax)
		{
			back->MeterUpAmount++;
			back->MeterUpTimes++;
		}
		else if (back->MeterUpTimes == MeterUpMax)
		{
			back->MeterUpTimes = 0;
			back->DoMeterUp = FALSE;
		}
	}
}

void BackGround::MeterDown(BackGround* back)
{
	if (back->DoMeterDown == TRUE)
	{
		if (back->MeterDownTimes < MeterDownMax)
		{
			back->MeterDownAmount++;
			back->MeterDownTimes++;
		}
		else if (back->MeterDownTimes == MeterDownMax)
		{
			back->MeterDownTimes = 0;
			back->DoMeterDown = FALSE;
		}
	}
}

void BackGround::DetectiveDraw(BackGround* back)
{
	DrawExtendGraph(back->CenterX - back->ItemVel * 3, back->CenterY - back->ItemVel,
		back->CenterX + back->ItemVel * 3, back->CenterY + back->ItemVel, FrameGr, TRUE);
	DrawFormatString(CenterX - MaxVel * 2 + 32,
		CenterY - MaxVel + 64, Gold, DetecStartMes);
	DrawFormatString(CenterX - 128,
		CenterY + 64, Gold, "�͂�      ������");
	DrawBox(CenterX - 128, CenterY + 64,
		CenterX - 60, CenterY + 96, Gold, FALSE);
	DrawBox(CenterX + 50, CenterY + 64,
		CenterX + 150, CenterY + 96, Gold, FALSE);
}

void BackGround::ItemDraw(int Max)
{
	for (int i = 0; i < MenuMax; i++)
	{
		if (MenuY[i] + MenuYVel > 60 &&
			MenuY[i] + MenuYVel < 600)
		{
			MenuDraw = TRUE;
		}
		else
		{
			MenuDraw = FALSE;
		}

		if (MenuDraw == TRUE)
		{
			DrawBox((int)MenuX[i], MenuY[i] + MenuYVel,
				(int)MenuX[i] + 70, MenuY[i] + 70 + MenuYVel,
				Silver, TRUE);
			if (i < Max)
			{
				DrawExtendGraph((int)MenuX[i], MenuY[i] + MenuYVel,
					(int)MenuX[i] + 70, MenuY[i] + MenuYVel + 70,
					ItemsTrue[i], TRUE);
			}
			else if (i == 7)
			{
				DrawExtendGraph((int)MenuX[i], MenuY[i] + MenuYVel,
					(int)MenuX[i] + 70, MenuY[i] + MenuYVel + 70,
					Mark[0], TRUE);
			}
			else if (i == 8)
			{
				DrawExtendGraph((int)MenuX[i], MenuY[i] + MenuYVel,
					(int)MenuX[i] + 70, MenuY[i] + MenuYVel + 70,
					Mark[1], TRUE);
			}
		}
	}
}