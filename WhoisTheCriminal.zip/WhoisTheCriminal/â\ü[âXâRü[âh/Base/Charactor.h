#pragma once

class Charactor
{
	public:
	//�T��
	int DetectiveTalk[40];
	int DetectiveGr;
	//�l�R�R
	int NekokoTalk[25];
	int NekokoGr;
	//�x�@
	int PoliceTalk[25];
	int PoliceGr;
	//��
	int UtaTalk[20];
	int UtaGr;
	//����
	int YuaTalk[20];
	int YuaGr;
	//�z
	int RinTalk[20];
	int RinGr;

	//int Search(int Flag);

	Charactor();
};