#include "DxLib.h"
#include "Sounds.h"

Sounds::Sounds()
{
	BGM[0] = LoadSoundMem("Materials/Sound/BGM/Title.mp3");
	BGM[1] = LoadSoundMem("Materials/Sound/BGM/Ponkotsu.mp3");
	BGM[2] = LoadSoundMem("Materials/Sound/BGM/Clear.mp3");
	BGM[3] = LoadSoundMem("Materials/Sound/BGM/Bad.mp3");
	BGM[4] = LoadSoundMem("Materials/Sound/BGM/Search.mp3");
	BGM[5] = LoadSoundMem("Materials/Sound/BGM/Thinking.mp3");
	SE = LoadSoundMem("Materials/Sound/SE/ItemGet.mp3");
	BGMVolume = 4;
	SEVolume = 4;

	for (int i = 0; i < 6; i++)
	{
		ChangeVolumeSoundMem(BGMVolume * 10, BGM[i]);
	}

	ChangeVolumeSoundMem(SEVolume * 10, SE);
}

void Sounds::PlayTitleSounds()
{
	for (int i = 0; i < 6; i++)
	{
		if (i != 0)
		{
			StopSoundMem(BGM[i]);
		}
	}

	if (CheckSoundMem(BGM[0]) == 0)
	{
		PlaySoundMem(BGM[0], DX_PLAYTYPE_BACK);
	}
}

void Sounds::PlayPonkotsuSounds()
{
	for (int i = 0; i < 6; i++)
	{
		if (i != 1)
		{
			StopSoundMem(BGM[i]);
		}
	}

	if (CheckSoundMem(BGM[1]) == 0)
	{
		PlaySoundMem(BGM[1], DX_PLAYTYPE_BACK);
	}
}

void Sounds::PlayClearSounds()
{
	for (int i = 0; i < 6; i++)
	{
		if (i != 2)
		{
			StopSoundMem(BGM[i]);
		}
	}

	if (CheckSoundMem(BGM[2]) == 0)
	{
		PlaySoundMem(BGM[2], DX_PLAYTYPE_BACK);
	}
}

void Sounds::PlayBadSounds()
{
	for (int i = 0; i < 6; i++)
	{
		if (i != 3)
		{
			StopSoundMem(BGM[i]);
		}
	}

	if (CheckSoundMem(BGM[3]) == 0)
	{
		PlaySoundMem(BGM[3], DX_PLAYTYPE_BACK);
	}
}

void Sounds::PlaySearchSounds()
{
	for (int i = 0; i < 6; i++)
	{
		if (i != 4)
		{
			StopSoundMem(BGM[i]);
		}
	}

	if (CheckSoundMem(BGM[4]) == 0)
	{
		PlaySoundMem(BGM[4], DX_PLAYTYPE_BACK);
	}
}

void Sounds::PlayThinkingSounds()
{
	for (int i = 0; i < 6; i++)
	{
		if (i != 5)
		{
			StopSoundMem(BGM[i]);
		}
	}

	if (CheckSoundMem(BGM[5]) == 0)
	{
		PlaySoundMem(BGM[5], DX_PLAYTYPE_BACK);
	}
}

void Sounds::PlayItemGetSounds()
{
	if (CheckSoundMem(SE) == 0)
	{
		PlaySoundMem(SE, DX_PLAYTYPE_BACK);
	}
}