#include "DxLib.h"
#include "GameStrings.h"

GameStrings::GameStrings()
{
	for (int i = 0; i < 256; i++)
	{
		for (int j = 0; j < 256; j++)
		{
			MainStrings[i][j] = { 0 };
		}
	}
	FH = 0;
	Flag = 0;
	OldFlag = 0;
}

GameStrings::~GameStrings()
{

}

void GameStrings::ReadFile(const char* FileName, int Max)
{
	FH = FileRead_open(FileName);

	for (int i = 0; i < Max; i++)
	{
		FileRead_gets(MainStrings[i],
			sizeof(MainStrings), FH);
	}

	FileRead_close(FH);
}