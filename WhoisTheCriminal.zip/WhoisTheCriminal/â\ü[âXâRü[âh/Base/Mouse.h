#include "BackGround.h"
#pragma once

class Mouse
{
	public :

	int PosX, PosY;
	int ClickTimer;

	//curosrGr
	int Gr;

	//void SceneTransition(BackGround* back, Sound* sound);

	//void TutorialStory(BackGround* back, Tutorial* TutoStr);

	void MouseDraw();

	int Collision(int PX1, int PY1,
		int PX2,int PY2,int EX1, int EY1,
		int EX2, int EY2);

	Mouse();
	~Mouse();
};