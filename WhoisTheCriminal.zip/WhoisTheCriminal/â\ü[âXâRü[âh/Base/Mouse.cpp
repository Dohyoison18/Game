#include "Dxlib.h"
#include "Mouse.h"
#include "DrawString.h"

Mouse::Mouse()
{
	PosX = 0, PosY = 0;
	ClickTimer = 20;
	Gr = LoadGraph("Materials/AllUse/Gr/cursor.png");
	SetMouseDispFlag(FALSE);
}

Mouse::~Mouse()
{

}

int Mouse::Collision(int PX1, int PY1,
	int PX2, int PY2, int EX1, int EY1,
	int EX2, int EY2)
{
	if (PX1 <= EX2 && EX1 <= PX2 && PY1 <= EY2 && EY1 <= PY2)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//void Mouse::SceneTransition(BackGround* back, Sound* sound)
//{
//	GetMousePoint(&PosX, &PosY);
//
//	if (ClickTimer >= 0)
//	{
//		ClickTimer--;
//	}
//
//	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
//		ClickTimer <= 0)
//	{
//		ClickTimer = 20;
//
//		//�^�C�g��
//		if (back->Scene == 0)
//		{
//			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
//				700, 600, 900, 640) == 1)
//			{
//				back->OldScene = back->Scene;
//				//���O���͂�
//				back->Scene = 1;
//			}
//			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
//				700, 665, 900, 705) == 1)
//			{
//				back->OldScene = back->Scene;
//				//�I�v�V������
//				back->Scene = 2;
//			}
//			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
//				700, 730, 900, 770) == 1)
//			{
//				DxLib_End();
//			}
//		}
//		else if (back->Scene == 2)
//		{
//			//BGMVolume / SEVolume / Back
//			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
//				510, 350, 560, 400) == 1)
//			{
//				if (sound->BGMVolume > 0)
//				{
//					sound->BGMVolume--;
//				}
//			}
//			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
//				1050, 350, 1100, 400) == 1)
//			{
//				if (sound->BGMVolume < 5)
//				{
//					sound->BGMVolume++;
//				}
//			}
//			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
//				510, 490, 560, 540) == 1)
//			{
//				if (sound->SEVolume > 0)
//				{
//					sound->SEVolume--;
//				}
//			}
//			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
//				1050, 490, 1100, 540) == 1)
//			{
//				if (sound->SEVolume < 5)
//				{
//					sound->SEVolume++;
//				}
//			}
//			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
//				758, 565, 918, 605) == 1)
//			{
//				//�O�񂪃��C���̏ꍇ�̓��C��,�^�C�g���̏ꍇ�̓^�C�g���ɖ߂�
//				back->Scene = back->OldScene;
//			}
//		}
//	}
//}

//void Mouse::TutorialStory(BackGround* back, Tutorial* TutoStr)
//{
//	GetMousePoint(&PosX, &PosY);
//
//	if (ClickTimer >= 0)
//	{
//		ClickTimer--;
//	}
//
//	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
//		ClickTimer <= 0)
//	{
//		ClickTimer = 30;
//
//		if (TutoStr->Flag < 8)
//		{
//			TutoStr->Flag++;
//			ChangeMessage(TutoStr->MainStrings[TutoStr->Flag]);
//		}
//	}
//}

void Mouse::MouseDraw()
{
	DrawExtendGraph(PosX - 5, PosY,
		PosX + 15, PosY + 23, Gr, TRUE);
}