#include "DxLib.h"
#include "Charactor.h"

Charactor::Charactor()
{
	for (int i = 0; i < 40; i++)
	{
		DetectiveTalk[i] = -1;
	}

	for (int i = 0; i < 25; i++)
	{
		NekokoTalk[i] = -1;
		PoliceTalk[i] = -1;
	}

	for (int i = 0; i < 20; i++)
	{
		UtaTalk[i] = -1;
		YuaTalk[i] = -1;
		RinTalk[i] = -1;
	}
	DetectiveGr = LoadGraph("Materials/AllUse/Gr/detective_1.png");
	NekokoGr = LoadGraph("Materials/AllUse/Gr/nekoko_1.png");
	PoliceGr = LoadGraph("Materials/AllUse/Gr/police.png");
	YuaGr = LoadGraph("Materials/AllUse/Gr/yua.png");
	RinGr = LoadGraph("Materials/AllUse/Gr/rin.png");
	UtaGr = LoadGraph("Materials/AllUse/Gr/uta.png");
}

//int Charactor::Search(int Flag)
//{
//	for (int i = 0; i < 20; i++)
//	{
//		if (Flag == DetectiveTalk[i])
//		{
//			return 1;
//			DetectiveTalk[i] = 0;
//		}
//		else if (Flag == NekokoTalk[i])
//		{
//			return 2;
//			NekokoTalk[i] = 0;
//		}
//		else if (Flag == PoliceTalk[i])
//		{
//			return 3;
//			PoliceTalk[i] = 0;
//		}
//		else
//		{
//			return 0;
//		}
//	}
//}