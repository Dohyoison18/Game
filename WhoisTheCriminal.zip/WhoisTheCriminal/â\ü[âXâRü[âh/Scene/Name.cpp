#include "DxLib.h"
#include "Name.h"

Name::Name()
{
	TitleGr = LoadGraph("Materials/Title/Gr/title.png");
}

void Name::Draw(BackGround* back)
{
	SetFontSize(40);

	DrawGraph(0, 0, TitleGr, TRUE);
	DrawExtendGraph(330, 185,
		1270, 715, FrameGr, TRUE);

	//����
	DrawString(500, 285, "���O����͂��Ă�������", FrameColor);
	DrawLine(500, 565, 940, 565, FrameColor, 5);

	if (KeyInputString(500, 520, 10,
		back->name, FALSE) == 1)
	{
		back->OldScene = back->Scene;
		back->Scene = 3;
		back->Bright = 0;
	}

}