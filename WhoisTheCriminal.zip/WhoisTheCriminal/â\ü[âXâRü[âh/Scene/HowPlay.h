#include "../Base/BackGround.h"
#include "../Base/Mouse.h"
#pragma once
class HowPlay : public Mouse
{
	private :
	int TitleGr;
	int Gr;

	public :

	HowPlay();
	void Click(BackGround* back);
	void Draw();
};