#include "../Base/GameStrings.h"
#include "../Base/BackGround.h"
#include "../Base/DrawString.h"
#include "../Base/Mouse.h"
#include "../Base/Charactor.h"
#include "../Base/Sounds.h"
#pragma once

class Tutorial : public GameStrings, public BackGround,
	public Mouse, public Charactor
{
	private:

	//�O���t�B�b�N
	int TutorialGr;
	int BackNekoGr;
	
	//�}�b�N�X
	const int ItemMax = 2;

	bool ItemGet[2];
	bool ItemSet[2];
	bool ItemConfirmation[2];
	int ItemMenuFlag;

	char Item1Strings[256][256];
	char Item2Strings[256][256];

	void ReadFileItem1(const char* FileName, int Max);
	void ReadFileItem2(const char* FileName, int Max);

	//void ItemGetDraw();

	void TalkSet();

	public:

	void Update(BackGround* back, Sounds* sound);

	void BackDraw(BackGround* back);

	Tutorial();
};