#include "../Base/BackGround.h"
#include "../Base/Mouse.h"
#include "../Base/Sounds.h"
#pragma once

class Title : public BackGround, public Mouse
{
	private :
		int TitleGr;
	public :
		void Update(BackGround* back, Sounds* sound);

		void Draw();

		void BackDraw();

		Title();
};