#include "../Base/GameStrings.h"
#include "../Base/BackGround.h"
#include "../Base/DrawString.h"
#include "../Base/Mouse.h"
#include "../Base/Charactor.h"
#include "../Base/Sounds.h"

#pragma once

class End : public GameStrings, public BackGround,
	public Mouse, public Charactor
{
	private:
	const char* Story = "Materials/End/Text/End.txt";
	const int End1Gr = LoadGraph("Materials/End/Gr/End1.png");
	const int End2Gr = LoadGraph("Materials/End/Gr/End2.png");
	const int End3Gr = LoadGraph("Materials/End/Gr/End3.png");

	int DetectiveEnd[3][10] = { 0 };
	int PoliceEnd[3][10] = { 0 };
	int NekokoEnd[3][10] = { 0 };
	
	void ChooseNextDraw();

	public:
	void EndClick(BackGround* back, Sounds* sound);
	void DrawEnd(BackGround* back);
	End();
	~End();
};

