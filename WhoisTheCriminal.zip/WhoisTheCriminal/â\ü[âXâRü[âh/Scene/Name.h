#include "../Base/BackGround.h"
#pragma once

class Name : public BackGround
{
	private:
	int TitleGr;

	public :

	Name();

	void Draw(BackGround* back);
};