#include "DxLib.h"
#include "End.h"

//���b�Z�[�W�{�b�N�X��X���W
#define MESSAGE_BOX_X_POS 250
//���b�Z�[�W�{�b�N�X��Y���W
#define MESSAGE_BOX_Y_POS 720

End::End()
{
	Flag = 1;
	FH = 0;
	ReadFile(Story, 72);
	DetectiveEnd[0][0] = 4;
	DetectiveEnd[0][1] = 8;
	DetectiveEnd[0][2] = 10;
	DetectiveEnd[0][3] = 15;
	DetectiveEnd[1][0] = 25;
	DetectiveEnd[1][1] = 27;
	DetectiveEnd[1][2] = 29;
	DetectiveEnd[1][3] = 31;
	DetectiveEnd[1][4] = 34;
	DetectiveEnd[1][5] = 35;
	DetectiveEnd[1][6] = 37;
	DetectiveEnd[1][7] = 42;
	DetectiveEnd[2][0] = 53;
	DetectiveEnd[2][1] = 54;
	DetectiveEnd[2][2] = 57;
	DetectiveEnd[2][3] = 60;
	DetectiveEnd[2][4] = 62;
	DetectiveEnd[2][5] = 65;
	PoliceEnd[0][0] = 3;
	PoliceEnd[0][1] = 5;
	PoliceEnd[0][2] = 6;
	PoliceEnd[0][3] = 7;
	PoliceEnd[0][4] = 9;
	PoliceEnd[1][0] = 26;
	PoliceEnd[1][1] = 28;
	PoliceEnd[1][2] = 30;
	PoliceEnd[1][3] = 33;
	PoliceEnd[1][4] = 36;
	PoliceEnd[2][0] = 52;
	PoliceEnd[2][1] = 56;
	PoliceEnd[2][2] = 58;
	NekokoEnd[0][0] = 11;
	NekokoEnd[0][1] = 16;
	NekokoEnd[1][0] = 32;
	NekokoEnd[1][1] = 43;
	NekokoEnd[2][0] = 55;
	NekokoEnd[2][1] = 59;
	NekokoEnd[2][2] = 61;
	NekokoEnd[2][3] = 63;
	NekokoEnd[2][4] = 66;
}

void End::ChooseNextDraw()
{
	DrawExtendGraph(CenterX - 600, CenterY - 200,
		CenterX + 600, CenterY + 200, FrameGr, TRUE);
	DrawFormatString(CenterX - 160,
		CenterY - 100, Gold, "������x���킵�܂���?");
	DrawFormatString(CenterX - 128,
		CenterY + 64, Gold, "�͂�      ������");
	DrawBox(CenterX - 128, CenterY + 64,
		CenterX - 60, CenterY + 96, Gold, FALSE);
	DrawBox(CenterX + 50, CenterY + 64,
		CenterX + 150, CenterY + 96, Gold, FALSE);
}

void End::EndClick(BackGround* back, Sounds* sound)
{
	MingTurn(back);

	GetMousePoint(&PosX, &PosY);

	if (ClickTimer >= 0)
	{
		ClickTimer--;
	}

	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
		ClickTimer <= 0 && back->HowEnd == 1)
	{
		sound->PlayBadSounds();
		ClickTimer = 30;
		if (Flag > 2 && Flag < 11)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 11)
		{
			Flag = 13;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 13)
		{
			Flag = 15;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 15)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 1)
		{
			Flag = 3;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 16)
		{
			Flag++;
			back->Bright = 0;
		}
		else if (Flag == 17)
		{
			Flag++;
		}
		else if (Flag == 18)
		{
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				CenterX - 128, CenterY + 64,
				CenterX - 60, CenterY + 96) == 1)
			{
				back->OldScene = back->Scene;
				back->Scene = 4;
				back->MeterDownAmount = 0;
				back->Initialize = TRUE;
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				CenterX + 50, CenterY + 64,
				CenterX + 150, CenterY + 96) == 1)
			{
				back->Scene = 0;
			}
		}
	}

	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
		ClickTimer <= 0 && back->HowEnd == 2)
	{
		sound->PlayPonkotsuSounds();
		ClickTimer = 30;
		if (Flag > 24 && Flag < 37)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 37)
		{
			Flag = 39;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag >= 39 && Flag < 40)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 40)
		{
			Flag = 42;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag >= 42 && Flag < 43)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 1)
		{
			Flag = 25;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 43)
		{
			Flag++;
			back->Bright = 0;
		}
		else if (Flag == 44)
		{
			Flag++;
		}
		else if (Flag == 45)
		{
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				CenterX - 128, CenterY + 64,
				CenterX - 60, CenterY + 96) == 1)
			{
				back->OldScene = back->Scene;
				back->Scene = 4;
				back->MeterDownAmount = 0;
				back->Initialize = TRUE;
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				CenterX + 50, CenterY + 64,
				CenterX + 150, CenterY + 96) == 1)
			{
				back->Scene = 0;
			}
		}
	}

	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
		ClickTimer <= 0 && back->HowEnd == 3)
	{
		sound->PlayClearSounds();
		ClickTimer = 30;
		if (Flag > 49 && Flag < 66)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 1)
		{
			Flag = 50;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 66)
		{
			Flag++;
			back->Bright = 0;
		}
		else if (Flag == 67)
		{
			back->Scene = 0;
			back->Initialize = TRUE;
		}
	}
}

void End::DrawEnd(BackGround* back)
{
	SetFontSize(32);

	if (back->HowEnd == 1)
	{
		if (Flag == 17 || Flag == 18)
		{
			SetDrawBright(back->Bright, back->Bright, back->Bright);
		}

		if (Flag == 17)
		{
			DrawGraph(0, 0, End3Gr, TRUE);
		}

		if (Flag > 2 && Flag < 17)
		{
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
			if (Flag != 12 && Flag != 13 && Flag != 14 && Flag != 20)
			{
				DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
			}
			drawMessage(White);
		}

		if (Flag == 18)
		{
			ChooseNextDraw();
		}

		for (int i = 0; i < 10; i++)
		{
			if (DetectiveEnd[0][i] == Flag)
			{
				DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, back->name);
			}
			else if (NekokoEnd[0][i] == Flag)
			{
				DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "�l�R�R");
			}
			else if (PoliceEnd[0][i] == Flag)
			{
				DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, PoliceGr, TRUE);
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "�x�@");
			}
		}
	}
	else if (back->HowEnd == 2)
	{
		if (Flag == 44 || Flag == 45)
		{
			SetDrawBright(back->Bright, back->Bright, back->Bright);
		}

		if (Flag == 44)
		{
			SetDrawBright(back->Bright, back->Bright, back->Bright);
			DrawGraph(0, 0, End2Gr, TRUE);
		}

		if (Flag > 24 && Flag < 44)
		{
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
			if (Flag != 39 && Flag != 40 )
			{
				DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
			}
			drawMessage(White);
		}

		for (int i = 0; i < 10; i++)
		{
			if (DetectiveEnd[1][i] == Flag)
			{
				DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, back->name);
			}
			else if (NekokoEnd[1][i] == Flag)
			{
				DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "�l�R�R");
			}
			else if (PoliceEnd[1][i] == Flag)
			{
				DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, PoliceGr, TRUE);
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "�x�@");
			}
		}

		if (Flag == 45)
		{
			ChooseNextDraw();
		}
	}
	else if (back->HowEnd == 3)
	{
		if (Flag > 49 && Flag < 67)
		{
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
			if (Flag != 50 && Flag != 51 && Flag != 64)
			{
				DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
			}
			drawMessage(White);
		}
		else if (Flag == 67)
		{
			SetDrawBright(back->Bright, back->Bright, back->Bright);
			DrawGraph(0, 0, End1Gr, TRUE);
		}

		for (int i = 0; i < 10; i++)
		{
			if (DetectiveEnd[2][i] == Flag)
			{
				DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, back->name);
			}
			else if (NekokoEnd[2][i] == Flag)
			{
				DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "�l�R�R");
			}
			else if (PoliceEnd[2][i] == Flag)
			{
				DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, PoliceGr, TRUE);
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "�x�@");
			}
		}
	}

	MouseDraw();
}