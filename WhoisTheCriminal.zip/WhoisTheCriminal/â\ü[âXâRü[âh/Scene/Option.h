#include "../Base/BackGround.h"
#include "../Base/Mouse.h"
#include "../Base/Sounds.h"
#pragma once

class Option : public BackGround, public Mouse
{
	private :
		int TitleGr;
	public :

		Option();
		void Update(BackGround* back, Sounds* sound);
		void Draw(BackGround* back, Sounds* sound);
};