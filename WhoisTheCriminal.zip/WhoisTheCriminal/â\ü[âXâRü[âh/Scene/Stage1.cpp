#include "DxLib.h"
#include "Stage1.h"

//���b�Z�[�W�{�b�N�X��X���W
#define MESSAGE_BOX_X_POS 250
//���b�Z�[�W�{�b�N�X��Y���W
#define MESSAGE_BOX_Y_POS 720

#define MenuMax 9
#define MaxVel 200
#define MaxMove 1600

const int WIN_WIDTH = 1600; //�E�B���h�E����
const int WIN_HEIGHT = 900;//�E�B���h�E�c��

Stage1::Stage1()
{
	Stage1Gr = LoadGraph("Materials/Stage1/Gr/MainMap.png");
	Items[0] = LoadGraph("Materials/Stage1/Gr/denkou.png");
	Items[1] = LoadGraph("Materials/Stage1/Gr/kabin.png");
	Items[2] = LoadGraph("Materials/Stage1/Gr/mizuato.png");
	Items[3] = LoadGraph("Materials/Stage1/Gr/supana.png");
	Items[4] = LoadGraph("Materials/Stage1/Gr/hondana.png");
	Items[5] = LoadGraph("Materials/Stage1/Gr/butterfly_nail.png");
	Items[6] = LoadGraph("Materials/Stage1/Gr/atama.png");
	SelectGr = LoadGraph("Materials/Stage1/Gr/Select.png");
	TalkToHumanGr = LoadGraph("Materials/Stage1/Gr/hito_mark.png");
	ReadFile(Stage1Story, 120);
	ReadFileAll();
	Flag = 0;
	Detective = FALSE;
	for (int i = 0; i < ItemMax; i++)
	{
		ItemGet[i] = FALSE;
		ItemSet[i] = FALSE;
	}
	for (int i = 0; i < MenuMax - 3; i++)
	{
		ItemsTrue[i] = 0;
	}
	CharaSelect = FALSE;
	Where = 0;
	MapVel = 0;
	SceneMove = FALSE;
	MenuFlag = FALSE;
	for (int i = 0; i < 3; i++)
	{
		ItemGetAfter[i] = FALSE;
		DoTalk[i] = FALSE;
		TalkCharacter[i] = FALSE;
	}
	TalkSet();
}

void Stage1::ReadFileAll()
{
	FH = FileRead_open(Stage1Item1);

	for (int i = 0; i < 10; i++)
	{
		FileRead_gets(Item1Strings[i],
			sizeof(Item1Strings), FH);
	}

	FileRead_close(FH);

	FH = FileRead_open(Stage1Item2);

	for (int i = 0; i < 10; i++)
	{
		FileRead_gets(Item2Strings[i],
			sizeof(Item2Strings), FH);
	}

	FileRead_close(FH);

	FH = FileRead_open(Stage1Item3);

	for (int i = 0; i < 10; i++)
	{
		FileRead_gets(Item3Strings[i],
			sizeof(Item3Strings), FH);
	}

	FileRead_close(FH);

	FH = FileRead_open(Stage1Item4);

	for (int i = 0; i < 10; i++)
	{
		FileRead_gets(Item4Strings[i],
			sizeof(Item4Strings), FH);
	}

	FileRead_close(FH);

	FH = FileRead_open(Stage1Item5);

	for (int i = 0; i < 10; i++)
	{
		FileRead_gets(Item5Strings[i],
			sizeof(Item5Strings), FH);
	}

	FileRead_close(FH);

	FH = FileRead_open(Stage1Item6);

	for (int i = 0; i < 10; i++)
	{
		FileRead_gets(Item6Strings[i],
			sizeof(Item6Strings), FH);
	}

	FileRead_close(FH);

	FH = FileRead_open(Stage1Item7);

	for (int i = 0; i < 10; i++)
	{
		FileRead_gets(Item7Strings[i],
			sizeof(Item7Strings), FH);
	}

	FileRead_close(FH);

	FH = FileRead_open(Stage1Uta);

	for (int i = 0; i < 30; i++)
	{
		FileRead_gets(UtaStrings[i],
			sizeof(UtaStrings), FH);
	}

	FileRead_close(FH);

	FH = FileRead_open(Stage1Yua);

	for (int i = 0; i < 30; i++)
	{
		FileRead_gets(YuaStrings[i],
			sizeof(YuaStrings), FH);
	}

	FileRead_close(FH);

	FH = FileRead_open(Stage1Rin);

	for (int i = 0; i < 30; i++)
	{
		FileRead_gets(RinStrings[i],
			sizeof(RinStrings), FH);
	}

	FileRead_close(FH);
}

void Stage1::TalkSet()
{
	for (int i = 0; i < 25; i++)
	{
		if (i < 20)
		{
			Charactor::PoliceTalk[i] = -1;
		}
		Charactor::NekokoTalk[i] = -1;
	}
	for (int i = 0; i < 40; i++)
	{
		Charactor::DetectiveTalk[i] = -1;
	}
	Charactor::DetectiveTalk[0] = 1;
	Charactor::DetectiveTalk[1] = 3;
	Charactor::DetectiveTalk[2] = 6;
	Charactor::DetectiveTalk[3] = 8;
	Charactor::DetectiveTalk[4] = 10;
	Charactor::DetectiveTalk[5] = 12;
	Charactor::DetectiveTalk[6] = 14;
	Charactor::DetectiveTalk[7] = 19;
	Charactor::DetectiveTalk[8] = 21;
	Charactor::DetectiveTalk[9] = 23;
	Charactor::DetectiveTalk[10] = 25;
	Charactor::DetectiveTalk[11] = 29;
	Charactor::DetectiveTalk[12] = 31;
	Charactor::DetectiveTalk[13] = 32;
	Charactor::DetectiveTalk[14] = 34;
	Charactor::DetectiveTalk[15] = 38;
	Charactor::DetectiveTalk[16] = 40;
	Charactor::DetectiveTalk[17] = 41;
	Charactor::DetectiveTalk[18] = 43;
	Charactor::DetectiveTalk[19] = 47;
	Charactor::DetectiveTalk[20] = 49;
	Charactor::DetectiveTalk[21] = 51;
	Charactor::DetectiveTalk[22] = 53;
	Charactor::DetectiveTalk[23] = 57;
	Charactor::DetectiveTalk[24] = 58;
	Charactor::DetectiveTalk[25] = 60;
	Charactor::DetectiveTalk[26] = 62;
	Charactor::DetectiveTalk[27] = 66;
	Charactor::DetectiveTalk[28] = 69;
	Charactor::DetectiveTalk[29] = 73;
	Charactor::DetectiveTalk[30] = 74;
	Charactor::DetectiveTalk[31] = 77;
	Charactor::DetectiveTalk[32] = 81;
	Charactor::DetectiveTalk[33] = 83;
	Charactor::DetectiveTalk[34] = 85;
	Charactor::DetectiveTalk[35] = 89;
	Charactor::DetectiveTalk[36] = 91;
	Charactor::DetectiveTalk[37] = 93;
	Charactor::DetectiveTalk[38] = 95;
	Charactor::DetectiveTalk[39] = 101;
	Charactor::PoliceTalk[0] = 2;
	Charactor::PoliceTalk[1] = 4;
	Charactor::PoliceTalk[2] = 5;
	Charactor::PoliceTalk[3] = 7;
	Charactor::PoliceTalk[4] = 9;
	Charactor::PoliceTalk[5] = 18;
	Charactor::PoliceTalk[6] = 20;
	Charactor::PoliceTalk[7] = 22;
	Charactor::PoliceTalk[8] = 24;
	Charactor::PoliceTalk[9] = 30;
	Charactor::PoliceTalk[10] = 33;
	Charactor::PoliceTalk[11] = 39;
	Charactor::PoliceTalk[12] = 42;
	Charactor::PoliceTalk[13] = 48;
	Charactor::PoliceTalk[14] = 50;
	Charactor::PoliceTalk[15] = 52;
	Charactor::PoliceTalk[16] = 59;
	Charactor::PoliceTalk[17] = 61;
	Charactor::PoliceTalk[18] = 67;
	Charactor::PoliceTalk[19] = 68;
	Charactor::PoliceTalk[20] = 75;
	Charactor::PoliceTalk[21] = 76;
	Charactor::PoliceTalk[22] = 97;
	Charactor::NekokoTalk[0] = 13;

	/*Charactor::DetectiveTalk[7] = 26;
	Charactor::DetectiveTalk[8] = 28;
	Charactor::DetectiveTalk[9] = 33;
	Charactor::DetectiveTalk[10] = 35;
	Charactor::DetectiveTalk[11] = 40;
	Charactor::DetectiveTalk[12] = 45;
	Charactor::DetectiveTalk[13] = 50;
	Charactor::DetectiveTalk[14] = 52;*/
}

void Stage1::SceneChange()
{
	if (Where == 0 &&
		SceneMove == TRUE)
	{
		if (MapVel < MaxMove)
		{
			MapVel += 100;
		}
		else if (MapVel == MaxMove)
		{
			Where = 1;
			SceneMove = FALSE;
		}
	}
	else if (Where == 1 &&
		SceneMove == TRUE)
	{
		if (MapVel > 0)
		{
			MapVel -= 100;
		}
		else if (MapVel == 0)
		{
			Where = 0;
			SceneMove = FALSE;
		}
	}
}

void Stage1::SceneChangeDraw()
{
	if (Where == 0)
	{
		DrawTriangle(WIN_WIDTH - 60, WIN_HEIGHT - 60,
			WIN_WIDTH - 60, WIN_HEIGHT - 10,
			WIN_WIDTH - 10, WIN_HEIGHT - 35, Silver, TRUE);
	}
	else if (Where == 1)
	{
		DrawTriangle(60, WIN_HEIGHT - 60, 10, WIN_HEIGHT - 35,
			60, WIN_HEIGHT - 10, Silver, TRUE);
	}
}

void Stage1::ItemGetStrings(BackGround* back)
{
	if (ItemSet[0] == TRUE)
	{
		ItemFlag[0]++;
		ChangeMessage(Item1Strings[ItemFlag[0]]);
		if (ItemFlag[0] == 3)
		{
			back->DoMeterUp = TRUE;
			ItemSet[0] = FALSE;
			ItemGet[0] = TRUE;
			ItemsTrue[0] = Items[0];
		}
	}

	if (ItemSet[1] == TRUE)
	{
		ItemFlag[1]++;
		ChangeMessage(Item2Strings[ItemFlag[1]]);

		if (ItemFlag[1] == 5)
		{
			back->DoMeterUp = TRUE;
			ItemSet[1] = FALSE;
			ItemGet[1] = TRUE;
			ItemsTrue[1] = Items[1];
		}
	}

	if (ItemSet[2] == TRUE)
	{
		ItemFlag[2]++;
		ChangeMessage(Item3Strings[ItemFlag[2]]);

		if (ItemFlag[2] == 4)
		{
			back->DoMeterUp = TRUE;
			ItemSet[2] = FALSE;
			ItemGet[2] = TRUE;
			ItemsTrue[2] = Items[2];
		}
	}

	if (ItemSet[3] == TRUE)
	{
		ItemFlag[3]++;
		ChangeMessage(Item4Strings[ItemFlag[3]]);

		if (ItemFlag[3] == 4 && ItemGetAfter[1] == FALSE)
		{
			ItemSet[3] = FALSE;
			ItemGetAfter[1] = TRUE;
		}

		if (ItemFlag[3] == 8 && ItemGetAfter[1] == TRUE)
		{
			back->DoMeterUp = TRUE;
			ItemGet[3] = TRUE;
			ItemSet[3] = FALSE;
			ItemsTrue[3] = Items[3];
		}
	}

	if (ItemSet[4] == TRUE)
	{
		ItemFlag[4]++;
		ChangeMessage(Item5Strings[ItemFlag[4]]);

		if (ItemFlag[4] == 5)
		{
			back->DoMeterUp = TRUE;
			ItemSet[4] = FALSE;
			ItemGet[4] = TRUE;
			ItemsTrue[4] = Items[4];
		}
	}

	if (ItemSet[5] == TRUE)
	{
		ItemFlag[5]++;
		ChangeMessage(Item6Strings[ItemFlag[5]]);

		if (ItemFlag[5] == 4)
		{
			back->DoMeterUp = TRUE;
			ItemSet[5] = FALSE;
			ItemGet[5] = TRUE;
			ItemsTrue[5] = Items[5];
		}
	}

	if (ItemSet[6] == TRUE)
	{
		ItemFlag[6]++;
		ChangeMessage(Item7Strings[ItemFlag[6]]);

		if (ItemFlag[6] == 5)
		{
			back->DoMeterUp = TRUE;
			ItemSet[6] = FALSE;
			ItemGet[6] = TRUE;
			ItemsTrue[6] = Items[6];
		}
	}
}

void Stage1::ItemGetStringsDraw(BackGround* back)
{
	if (ItemSet[0] == TRUE)
	{
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
		if (ItemFlag[0] == 1)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (ItemFlag[0] == 2)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		drawMessage(White);
	}

	if (ItemSet[1] == TRUE)
	{
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
		if (ItemFlag[1] == 1 || ItemFlag[1] == 3)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (ItemFlag[1] == 2 || ItemFlag[1] == 4)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		drawMessage(White);
	}

	if (ItemSet[2] == TRUE)
	{
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
		if (ItemFlag[2] == 1 || ItemFlag[2] == 3)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (ItemFlag[2] == 2)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		drawMessage(White);
	}

	if (ItemSet[3] == TRUE)
	{
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
		if (ItemFlag[3] == 1 || ItemFlag[3] == 3 || ItemFlag[3] == 5 ||
			ItemFlag[3] == 7)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (ItemFlag[3] == 2 || ItemFlag[3] == 6)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		drawMessage(White);
	}

	if (ItemSet[4] == TRUE)
	{
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
		if (ItemFlag[4] == 1 || ItemFlag[4] == 3)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (ItemFlag[4] == 2 || ItemFlag[4] == 4)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		drawMessage(White);
	}

	if (ItemSet[5] == TRUE)
	{
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
		if (ItemFlag[5] == 1 || ItemFlag[5] == 3)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (ItemFlag[5] == 2)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		drawMessage(White);
	}

	if (ItemSet[6] == TRUE)
	{
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
		if (ItemFlag[6] == 1 || ItemFlag[6] == 3)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (ItemFlag[6] == 2 || ItemFlag[6] == 4)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		drawMessage(White);
	}
}

void Stage1::ItemCollision(BackGround* back)
{
	//�}�b�v���E�̃A�C�e������
	if (Where == 0 && Flag == 11 && CharaSelect == FALSE
		&& DoTalk[0] == FALSE && DoTalk[1] == FALSE
		&& DoTalk[2] == FALSE)
	{
		//�d�H�h���� / �ԕr / ��
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			510, 490, 710, 650) == 1 && ItemGet[0] == FALSE
			&& ItemSet[0] == FALSE && ItemSet[1] == FALSE &&
			ItemSet[2] == FALSE && ItemSet[3] == FALSE &&
			ItemSet[4] == FALSE && ItemSet[5] == FALSE &&
			ItemSet[6] == FALSE)
		{
			MeterUp(back);
			MeterDown(back);
			ItemSet[0] = TRUE;
			ItemFlag[0] = 0;
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			900, 580, 1150, 700) == 1 && ItemGet[1] == FALSE
			&& ItemSet[0] == FALSE && ItemSet[1] == FALSE &&
			ItemSet[2] == FALSE && ItemSet[3] == FALSE &&
			ItemSet[4] == FALSE && ItemSet[5] == FALSE &&
			ItemSet[6] == FALSE)
		{
			MeterUp(back);
			MeterDown(back);
			ItemSet[1] = TRUE;
			ItemFlag[1] = 0;
			ItemGetAfter[0] = TRUE;
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			600, 800, 1100, 880) == 1 && ItemGet[2] == FALSE
			&& ItemSet[0] == FALSE && ItemSet[1] == FALSE &&
			ItemSet[2] == FALSE && ItemSet[3] == FALSE &&
			ItemSet[4] == FALSE && ItemSet[5] == FALSE &&
			ItemSet[6] == FALSE)
		{
			MeterUp(back);
			MeterDown(back);
			ItemSet[2] = TRUE;
			ItemFlag[2] = 0;
		}
	}
	else if (Where == 1 && Flag == 11 && CharaSelect == FALSE
		&& DoTalk[0] == FALSE && DoTalk[1] == FALSE
		&& DoTalk[2] == FALSE)
	{
		//�X�p�i / �{�I / �l�C�� / ��
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			570, 620, 700, 720) == 1 && ItemGet[3] == FALSE
			&& ItemSet[0] == FALSE && ItemSet[1] == FALSE &&
			ItemSet[2] == FALSE && ItemSet[3] == FALSE &&
			ItemSet[4] == FALSE && ItemSet[5] == FALSE &&
			ItemSet[6] == FALSE)
		{
			ItemSet[3] = TRUE;
			ItemFlag[3] = 0;
			if (ItemGetAfter[1] == TRUE)
			{
				MeterUp(back);
				MeterDown(back);
				ItemSet[3] = TRUE;
				ItemFlag[3] = 4;
			}
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			720, 100, 1300, 600) == 1 && ItemGet[4] == FALSE
			&& ItemSet[0] == FALSE && ItemSet[1] == FALSE &&
			ItemSet[2] == FALSE && ItemSet[3] == FALSE &&
			ItemSet[4] == FALSE && ItemSet[5] == FALSE &&
			ItemSet[6] == FALSE)
		{
			MeterUp(back);
			MeterDown(back);
			ItemSet[4] = TRUE;
			ItemFlag[4] = 0;
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			1300, 740, 1340, 780) == 1 && ItemGet[5] == FALSE
			&& ItemSet[0] == FALSE && ItemSet[1] == FALSE &&
			ItemSet[2] == FALSE && ItemSet[3] == FALSE &&
			ItemSet[4] == FALSE && ItemSet[5] == FALSE &&
			ItemSet[6] == FALSE)
		{
			MeterUp(back);
			MeterDown(back);
			ItemSet[5] = TRUE;
			ItemFlag[5] = 0;
			ItemGetAfter[2] = TRUE;
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			912, 800, 2783, 899) == 1 && ItemGet[6] == FALSE
			&& ItemSet[0] == FALSE && ItemSet[1] == FALSE &&
			ItemSet[2] == FALSE && ItemSet[3] == FALSE &&
			ItemSet[4] == FALSE && ItemSet[5] == FALSE &&
			ItemSet[6] == FALSE)
		{
			MeterUp(back);
			MeterDown(back);
			ItemSet[6] = TRUE;
			ItemFlag[6] = 0;
		}
	}
}

void Stage1::MenuCollision(BackGround* back)
{
	//���j���[�̂Ƃ�(�A�C�e���m�F��)
	if (MenuFlag == TRUE)
	{
		for (int i = 0; i < MenuMax; i++)
		{
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				(int)MenuX[i], MenuY[i] + MenuYVel,
				(int)MenuX[i] + 70, MenuY[i] + 70 + MenuYVel) == 1 &&
				ItemGet[i] == TRUE && i < ItemMax)
			{
				MenuFlag = FALSE;
				ItemSet[i] = TRUE;
				ItemFlag[i] = 0;
				if (ItemGetAfter[1] == TRUE)
				{
					ItemFlag[3] = 4;
				}

				if (i == 0)
				{
					ChangeMessage(Item1Strings[ItemFlag[i]]);
				}
				else if (i == 1)
				{
					ChangeMessage(Item2Strings[ItemFlag[i]]);
				}
				else if (i == 2)
				{
					ChangeMessage(Item3Strings[ItemFlag[i]]);
				}
				else if (i == 3)
				{
					ChangeMessage(Item4Strings[ItemFlag[i]]);
				}
				else if (i == 4)
				{
					ChangeMessage(Item5Strings[ItemFlag[i]]);
				}
				else if (i == 5)
				{
					ChangeMessage(Item6Strings[ItemFlag[i]]);
				}
				else if (i == 6)
				{
					ChangeMessage(Item7Strings[ItemFlag[i]]);
				}
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				(int)MenuX[i], MenuY[i] + MenuYVel,
				(int)MenuX[i] + 70, MenuY[i] + 70 + MenuYVel) == 1 &&
				i == 7)
			{
				back->OldScene = back->Scene;
				back->Scene = 6;
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				(int)MenuX[i], MenuY[i] + MenuYVel,
				(int)MenuX[i] + 70, MenuY[i] + 70 + MenuYVel) == 1 &&
				i == 8)
			{
				back->OldScene = back->Scene;
				back->Scene = 2;
			}
		}
	}
}

void Stage1::TalkToTheCharacter(BackGround* back)
{
	//�b���Z���N�g��ʂ��o�Ă�����
	if (CharaSelect == TRUE && back->CharaSelectY >= 0)
	{
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			76, 100, 425, 455) == 1)
		{
			if (TalkCharacter[0] == TRUE && ItemGetAfter[0] == TRUE &&
				ItemGetAfter[2] == FALSE)
			{
				YuaFlag = 10;
			}
			else if (TalkCharacter[0] == TRUE && ItemGetAfter[0] == FALSE &&
				ItemGetAfter[2] == TRUE)
			{
				YuaFlag = 15;
			}
			else
			{
				YuaFlag = 0;
			}
			DoTalk[0] = TRUE;
			CharaSelect = FALSE;
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			600, 280, 950, 620) == 1)
		{
			if (TalkCharacter[1] == TRUE && ItemGetAfter[0] == TRUE &&
				ItemGetAfter[2] == FALSE)
			{
				UtaFlag = 10;
			}
			else if (TalkCharacter[1] == TRUE && ItemGetAfter[0] == FALSE &&
				ItemGetAfter[2] == TRUE)
			{
				UtaFlag = 17;
			}
			else
			{
				UtaFlag = 0;
			}
			DoTalk[1] = TRUE;
			CharaSelect = FALSE;
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			1150, 60, 1510, 410) == 1)
		{
			if (TalkCharacter[2] == TRUE && ItemGetAfter[0] == TRUE &&
				ItemGetAfter[2] == FALSE)
			{
				RinFlag = 11;
			}
			else if (TalkCharacter[2] == TRUE && ItemGetAfter[0] == FALSE &&
				ItemGetAfter[2] == TRUE)
			{
				RinFlag = 16;
			}
			else
			{
				RinFlag = 0;
			}
			DoTalk[2] = TRUE;
			CharaSelect = FALSE;
		}
	}

	//�����Ƃ̉�b/���Ƃ̉�b/�z�Ƃ̉�b
	if (DoTalk[0] == TRUE)
	{
		YuaFlag++;
		if (YuaFlag == 8 && ItemGetAfter[0] == TRUE)
		{
			YuaFlag = 11;
		}
		else if (YuaFlag == 8 && ItemGetAfter[2] == TRUE)
		{
			YuaFlag = 16;
		}
		else if (YuaFlag == 8)
		{
			DoTalk[0] = FALSE;
			TalkCharacter[0] = TRUE;
		}

		if (YuaFlag == 13 && ItemGetAfter[2] == TRUE)
		{
			YuaFlag = 16;
		}
		else if (YuaFlag == 13)
		{
			DoTalk[0] = FALSE;
		}

		if (YuaFlag == 19)
		{
			DoTalk[0] = FALSE;
		}
		ChangeMessage(YuaStrings[YuaFlag]);
	}
	else if (DoTalk[1] == TRUE)
	{
		UtaFlag++;
		if (UtaFlag == 8 && ItemGetAfter[0] == TRUE)
		{
			UtaFlag = 11;
		}
		else if (UtaFlag == 8 && ItemGetAfter[2] == TRUE)
		{
			UtaFlag = 18;
		}
		else if (UtaFlag == 8)
		{
			DoTalk[1] = FALSE;
			TalkCharacter[1] = TRUE;
		}

		if (UtaFlag == 15 && ItemGetAfter[2] == TRUE)
		{
			UtaFlag = 18;
		}
		else if (UtaFlag == 15)
		{
			DoTalk[1] = FALSE;
		}

		if (YuaFlag == 21)
		{
			DoTalk[1] = FALSE;
		}
		ChangeMessage(UtaStrings[UtaFlag]);
	}
	else if (DoTalk[2] == TRUE)
	{
		RinFlag++;

		if (RinFlag == 9 && ItemGetAfter[0] == TRUE)
		{
			RinFlag = 12;
		}
		else if (RinFlag == 9 && ItemGetAfter[2] == TRUE)
		{
			RinFlag = 17;
		}
		else if (RinFlag == 9)
		{
			DoTalk[2] = FALSE;
			TalkCharacter[2] = TRUE;
		}

		if (RinFlag == 14 && ItemGetAfter[2] == TRUE)
		{
			RinFlag = 17;
		}
		else if (RinFlag == 14)
		{
			DoTalk[2] = FALSE;
		}

		if (RinFlag == 21)
		{
			DoTalk[2] = FALSE;
		}
		ChangeMessage(RinStrings[RinFlag]);
	}
}

void Stage1::TalkToTheCharacterDraw(BackGround* back)
{
	if (CharaSelect == TRUE)
	{
		DrawGraph((int)back->CharaSelectX, (int)back->CharaSelectY,
			SelectGr, TRUE);
	}
	else
	{
		if (Where == 0 && MapVel == 0 && DoTalk[0] == FALSE &&
			DoTalk[1] == FALSE && DoTalk[2] == FALSE)
		{
			DrawExtendGraph(50, WIN_HEIGHT / 2, 178, WIN_HEIGHT / 2 + 128, TalkToHumanGr, TRUE);
		}
	}

	if (DoTalk[0] == TRUE)
	{
		if (YuaFlag == 1 || YuaFlag == 3 || YuaFlag == 5 || YuaFlag == 7 ||
			YuaFlag == 11 || YuaFlag == 16)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (YuaFlag == 2 || YuaFlag == 4 || YuaFlag == 6 || YuaFlag == 12 ||
			YuaFlag == 17)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, YuaGr, TRUE);

			if (YuaFlag < 4)
			{
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "???");
			}
			else
			{
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "��� ����");
			}
		}
		else if (YuaFlag == 18)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}

		if (YuaFlag <= 8 || YuaFlag >= 11 && YuaFlag <= 13 ||
			YuaFlag >= 16 && YuaFlag <= 19)
		{
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
			drawMessage(White);
		}
	}
	else if (DoTalk[1] == TRUE)
	{
		if (UtaFlag == 1 || UtaFlag == 3 || UtaFlag == 5 || UtaFlag == 7 ||
			UtaFlag == 11 || UtaFlag == 14 || UtaFlag == 18 || UtaFlag == 21)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (UtaFlag == 2 || UtaFlag == 4 || UtaFlag == 6 || UtaFlag == 12 ||
			UtaFlag == 13 || UtaFlag == 19 || UtaFlag == 20)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, UtaGr, TRUE);

			if (UtaFlag < 4)
			{
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "???");
			}
			else
			{
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "���� ��");
			}
		}

		if (UtaFlag <= 8 || UtaFlag >= 11 && UtaFlag <= 15 ||
			UtaFlag >= 16 && UtaFlag <= 21)
		{
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
			drawMessage(White);
		}
	}
	else if (DoTalk[2] == TRUE)
	{
		if (RinFlag == 1 || RinFlag == 3 || RinFlag == 5 || RinFlag == 8 ||
			RinFlag == 12 || RinFlag == 17 || RinFlag == 19)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (RinFlag == 2 || RinFlag == 4 || RinFlag == 6 || RinFlag == 7 ||
			RinFlag == 13 || RinFlag == 18)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, RinGr, TRUE);

			if (RinFlag < 6)
			{
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "???");
			}
			else
			{
				DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
					Chartreuse, "�V�Ð� �z");
			}
		}
		else if (RinFlag == 20)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}

		if (RinFlag <= 9 || RinFlag >= 12 && RinFlag <= 14 ||
			RinFlag >= 17 && RinFlag <= 21)
		{
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
			drawMessage(White);
		}
	}
}

void Stage1::Nothing(BackGround* back)
{
	if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		WIN_WIDTH - 70, 0, WIN_WIDTH, 70) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		50, WIN_HEIGHT / 2, 178, WIN_HEIGHT / 2 + 128) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		WIN_WIDTH - 60, WIN_HEIGHT - 60,
		WIN_WIDTH - 10, WIN_HEIGHT - 10) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		510, 490, 710, 650) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		900, 580, 1150, 700) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		600, 800, 1100, 880) != 1 && Where == 0 &&
		Flag == 11 && DoTalk[0] == FALSE &&
		DoTalk[1] == FALSE && DoTalk[2] == FALSE &&
		CharaSelect == FALSE && ItemSet[0] == FALSE &&
		ItemSet[1] == FALSE && ItemSet[2] == FALSE &&
		ItemSet[3] == FALSE && ItemSet[4] == FALSE &&
		ItemSet[5] == FALSE && ItemSet[6] == FALSE)
	{
		back->DoMeterDown = TRUE;
	}
	else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		WIN_WIDTH - 70, 0, WIN_WIDTH, 70) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		10, WIN_HEIGHT - 60, 60, WIN_HEIGHT - 10) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		570, 620, 700, 720) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		720, 100, 1300, 600) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		1300, 740, 1340, 780) != 1 &&
		Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
		912, 800, 2783, 899) != 1 && Where == 1 &&
		Flag == 11 && DoTalk[0] == FALSE &&
		DoTalk[1] == FALSE && DoTalk[2] == FALSE &&
		CharaSelect == FALSE && ItemSet[0] == FALSE &&
		ItemSet[1] == FALSE && ItemSet[2] == FALSE &&
		ItemSet[3] == FALSE && ItemSet[4] == FALSE &&
		ItemSet[5] == FALSE && ItemSet[6] == FALSE)
	{
		back->DoMeterDown = TRUE;
	}
}

void Stage1::Reasoning(BackGround* back)
{
	if (Where == 0)
	{
		SceneMove = TRUE;
	}

	SceneChange();

	MeterDown(back);

	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
		ClickTimer <= 0)
	{
		ClickTimer = 30;
		if (Flag < 14)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 14)
		{
			//�𖾂��悤���ĂƂ�
			Flag = 18;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag > 14 && Flag < 25)
		{
			//�؋�1��p�ӂ���Ƃ���܂�
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 25)
		{
			//�� / �ȊO�̃��j���[���������Ƃ�
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 700, 1570, 770) == 1)
			{
				Flag = 29;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 100, 1570, 770) == 1)
			{
				OldFlag = Flag;
				back->DoMeterDown = TRUE;
				Flag = 101;
				ChangeMessage(MainStrings[Flag]);
			}
		}
		else if (Flag > 25 && Flag < 34)
		{
			//�؋�2��p�ӂ���Ƃ���܂�
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 34)
		{
			//�{�I / �ȊO�̃��j���[���������Ƃ�
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 500, 1570, 570) == 1)
			{
				Flag = 38;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 100, 1570, 770) == 1)
			{
				OldFlag = Flag;
				back->DoMeterDown = TRUE;
				Flag = 101;
				ChangeMessage(MainStrings[Flag]);
			}
		}
		else if (Flag > 34 && Flag < 43)
		{
			//�؋�3��p�ӂ���Ƃ���܂�
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 43)
		{
			//�X�p�i / �ȊO�̃��j���[���������Ƃ�
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 400, 1570, 470) == 1)
			{
				Flag = 47;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 100, 1570, 770) == 1)
			{
				OldFlag = Flag;
				back->DoMeterDown = TRUE;
				Flag = 101;
				ChangeMessage(MainStrings[Flag]);
			}
		}
		else if (Flag > 43 && Flag < 53)
		{
			//�؋�4��p�ӂ���Ƃ���܂�
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 53)
		{
			//�X�p�i / �ȊO�̃��j���[���������Ƃ�
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 400, 1570, 470) == 1)
			{
				Flag = 57;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 100, 1570, 770) == 1)
			{
				OldFlag = Flag;
				back->DoMeterDown = TRUE;
				Flag = 101;
				ChangeMessage(MainStrings[Flag]);
			}
		}
		else if (Flag > 53 && Flag < 62)
		{
			//�؋�5��p�ӂ���Ƃ���܂�
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 62)
		{
			//�ԕr / �ȊO�̃��j���[���������Ƃ�
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 200, 1570, 270) == 1)
			{
				Flag = 66;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 100, 1570, 770) == 1)
			{
				OldFlag = Flag;
				back->DoMeterDown = TRUE;
				Flag = 101;
				ChangeMessage(MainStrings[Flag]);
			}
		}
		else if (Flag > 62 && Flag < 69)
		{
			//�؋�6��p�ӂ���Ƃ���܂�
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 69)
		{
			//�� / �ȊO�̃��j���[���������Ƃ�
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 300, 1570, 370) == 1)
			{
				Flag = 73;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 100, 1570, 770) == 1)
			{
				OldFlag = Flag;
				back->DoMeterDown = TRUE;
				Flag = 101;
				ChangeMessage(MainStrings[Flag]);
			}
		}
		else if (Flag > 69 && Flag < 77)
		{
			//�؋�7��p�ӂ���Ƃ���܂�
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 77)
		{
			//�ォ�猋��,��,�z
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				76, 100, 425, 455) == 1)
			{
				back->Bright = 0;
				back->HowEnd = 2;
				back->Scene = 5;
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				600, 280, 950, 620) == 1)
			{
				back->Bright = 0;
				back->HowEnd = 2;
				back->Scene = 5;
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1150, 60, 1510, 410) == 1)
			{
				Flag = 81;
				ChangeMessage(MainStrings[Flag]);
			}
		}
		else if (Flag > 81 && Flag < 85)
		{
			//�؋�8��p�ӂ���Ƃ���܂�
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 85)
		{
			//�l�C�� / �ȊO�̃��j���[���������Ƃ�
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 600, 1570, 670) == 1)
			{
				Flag = 89;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				1500, 100, 1570, 770) == 1)
			{
				OldFlag = Flag;
				back->DoMeterDown = TRUE;
				Flag = 101;
				ChangeMessage(MainStrings[Flag]);
			}
		}
		else if (Flag > 85 && Flag < 97)
		{
			//�Ō�܂�
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 97)
		{
			back->Bright = 0;
			back->HowEnd = 3;
			back->Scene = 5;
		}
		else if (Flag == 101)
		{
			Flag = OldFlag;
			ChangeMessage(MainStrings[Flag]);
		}
	}

	if (back->MeterDownAmount >= 300)
	{
		back->HowEnd = 2;
		back->Scene = 5;
	}
}

void Stage1::ReasoningDraw(BackGround* back)
{
	DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
	DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
	drawMessage(White);
	for (int i = 0; i < 7; i++)
	{
		DrawBox(1500, MenuY[i],
			1570, MenuY[i] + 70,
			Silver, TRUE);
		DrawExtendGraph(1500, MenuY[i],
			1570, MenuY[i] + 70,
			Items[i], TRUE);
		DrawBox(1500, MenuY[i],
			1570, MenuY[i] + 70,
			Gold, FALSE);
	}

	for (int i = 0; i < 40; i++)
	{
		if (DetectiveTalk[i] == Flag)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
	}

	for (int i = 0; i < 25; i++)
	{
		if (NekokoTalk[i] == Flag)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		else if (PoliceTalk[i] == Flag)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, PoliceGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�x�@");
		}
	}
}

void Stage1::Searching(BackGround* back)
{
	if (Flag == 0)
	{
		ChangeMessage(MainStrings[Flag]);
	}

	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
		ClickTimer <= 0)
	{
		ClickTimer = 30;

		//��b���i��
		if (Flag < 11)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}

		//���j���[���������Ƃ�
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			WIN_WIDTH - 70, 0, WIN_WIDTH, 70) == 1 && CharaSelect == FALSE)
		{
			if (MenuFlag == FALSE)
			{
				MenuFlag = TRUE;
			}
			else if (MenuFlag == TRUE)
			{
				MenuFlag = FALSE;
			}
		}

		//�L�����Ɖ�b���鏊��
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			50, WIN_HEIGHT / 2, 178, WIN_HEIGHT / 2 + 128) == 1 && CharaSelect == FALSE
			&& DoTalk[0] == FALSE && DoTalk[1] == FALSE && DoTalk[2] == FALSE)
		{
			CharaSelect = TRUE;
		}

		//Where��0�̎���Where��1�̎�(�}�b�v�J��)
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			WIN_WIDTH - 60, WIN_HEIGHT - 60,
			WIN_WIDTH - 10, WIN_HEIGHT - 10) == 1
			&& Where == 0 && Flag == 11)
		{
			SceneMove = TRUE;
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			10, WIN_HEIGHT - 60, 60, WIN_HEIGHT - 10) == 1
			&& Where == 1 && Flag == 11)
		{
			SceneMove = TRUE;
		}

		//�}�b�v���E�̃A�C�e������
		ItemCollision(back);

		MenuCollision(back);

		ItemGetStrings(back);

		//�L�����N�^�[�Ƙb��
		TalkToTheCharacter(back);

		if (ItemGet[0] == TRUE &&
			ItemGet[1] == TRUE &&
			ItemGet[2] == TRUE &&
			ItemGet[3] == TRUE &&
			ItemGet[4] == TRUE &&
			ItemGet[5] == TRUE &&
			ItemGet[6] == TRUE &&
			Detective == FALSE)
		{
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				CenterX - 128, CenterY + 64, CenterX - 60, CenterY + 96) == 1)
			{
				DoDetective = TRUE;
				Detective = TRUE;
				back->MeterAmountOld = back->MeterDownAmount;
				Flag++;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				CenterX + 50, CenterY + 64, CenterX + 150, CenterY + 96) == 1)
			{
				DoDetective = FALSE;
				Detective = TRUE;
			}
		}

		if (DoDetective == FALSE &&
			Detective == TRUE)
		{
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				0, WIN_HEIGHT - 32, 128, WIN_HEIGHT) == 1 &&
				Where == 0)
			{
				DoDetective = TRUE;
				Detective = TRUE;
				Flag++;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				WIN_WIDTH - 128, WIN_HEIGHT - 32, WIN_WIDTH, WIN_HEIGHT) == 1 &&
				Where == 1)
			{
				DoDetective = TRUE;
				Detective = TRUE;
				Flag++;
				ChangeMessage(MainStrings[Flag]);
			}
		}

		Nothing(back);
	}

	if (ItemGet[0] == TRUE &&
		ItemGet[1] == TRUE &&
		ItemGet[2] == TRUE &&
		ItemGet[3] == TRUE &&
		ItemGet[4] == TRUE &&
		ItemGet[5] == TRUE &&
		ItemGet[6] == TRUE)
	{
		ZoomUp(back);
	}

	if (CharaSelect == TRUE)
	{
		Bound(back);
	}
	else
	{
		back->CharaSelectY = -800;
		back->SelectFrame = 0;
	}

	if (MenuFlag == FALSE)
	{
		EaseIn(back);
	}
	else if (MenuFlag == TRUE)
	{
		MenuYVel += GetMouseWheelRotVol() * 10;
		EaseOut(back);
	}

	if (back->MeterDownAmount >= 300)
	{
		back->HowEnd = 1;
		back->Scene = 5;
	}

	MeterUp(back);
	MeterDown(back);

	if (Flag == 11)
	{
		SceneChange();
	}
}

void Stage1::SearchingDraw(BackGround* back)
{

	if (Flag != 0 && Flag != 11)
	{
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
		drawMessage(White);
	}

	for (int i = 0; i < 20; i++)
	{
		if (DetectiveTalk[i] == Flag)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (NekokoTalk[i] == Flag)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		else if (PoliceTalk[i] == Flag)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, PoliceGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�x�@");
		}
	}

	if (Flag == 11)
	{
		DrawTriangle(WIN_WIDTH - 70, 20, WIN_WIDTH - 45, 70,
			WIN_WIDTH - 20, 20, Silver, TRUE);

		ItemDraw(ItemMax);
	}

	if (ItemGet[0] == TRUE &&
		ItemGet[1] == TRUE &&
		ItemGet[2] == TRUE &&
		ItemGet[3] == TRUE &&
		ItemGet[4] == TRUE &&
		ItemGet[5] == TRUE &&
		ItemGet[6] == TRUE &&
		Detective == FALSE)
	{
		DetectiveDraw(back);
	}

	if (DoDetective == FALSE &&
		Detective == TRUE)
	{
		if (Where == 0)
		{
			DrawFormatString(0, WIN_HEIGHT - 32, Gold, "�����J�n");
		}
		else if (Where == 1)
		{
			DrawFormatString(WIN_WIDTH - 128, WIN_HEIGHT - 32, Gold, "�����J�n");
		}
	}

	if (Flag == 11)
	{
		SceneChangeDraw();
	}
	ItemGetStringsDraw(back);

	TalkToTheCharacterDraw(back);

	MouseDraw();
}

void Stage1::Update(BackGround* back, Sounds* sound)
{
	if (back->Initialize == TRUE)
	{
		if (back->HowEnd == 1)
		{
			Flag = 1;
			ClickTimer = 30;
			ChangeMessage(MainStrings[Flag]);
			for (int i = 0; i < ItemMax; i++)
			{
				ItemGet[i] = FALSE;
				ItemSet[i] = FALSE;
			}
			for (int i = 0; i < MenuMax - 3; i++)
			{
				ItemsTrue[i] = 0;
			}
			back->Initialize = FALSE;
			back->MeterUpAmount = 0;
		}
		else if (back->HowEnd == 2)
		{
			Flag = 18;
			ClickTimer = 30;
			ChangeMessage(MainStrings[Flag]);
			back->Initialize = FALSE;
			back->MeterUpAmount = 0;
		}
		else if (back->HowEnd == 3)
		{
			Flag = 0;
			ClickTimer = 30;
			Detective = FALSE;
			for (int i = 0; i < ItemMax; i++)
			{
				ItemGet[i] = FALSE;
				ItemSet[i] = FALSE;
			}
			for (int i = 0; i < MenuMax - 3; i++)
			{
				ItemsTrue[i] = 0;
			}
			CharaSelect = FALSE;
			Where = 0;
			MapVel = 0;
			SceneMove = FALSE;
			MenuFlag = FALSE;
			for (int i = 0; i < 3; i++)
			{
				ItemGetAfter[i] = FALSE;
				DoTalk[i] = FALSE;
				TalkCharacter[i] = FALSE;
			}
			back->Initialize = FALSE;
			back->MeterUpAmount = 0;
			back->MeterDownAmount = 0;
		}
	}

	MingTurn(back);

	GetMousePoint(&PosX, &PosY);

	if (ClickTimer >= 0)
	{
		ClickTimer--;
	}

	if (DoDetective == FALSE)
	{
		sound->PlaySearchSounds();
		Searching(back);
	}

	if (Detective == TRUE &&
		DoDetective == TRUE)
	{
		sound->PlayThinkingSounds();
		Reasoning(back);
	}
}

void Stage1::BackDraw(BackGround* back)
{
	SetDrawBright(back->Bright, back->Bright, back->Bright);
	DrawGraph(-MapVel, 0, Stage1Gr, TRUE);
	SetFontSize(32);

	if (DoDetective == FALSE)
	{
		SearchingDraw(back);
	}
	else if (Detective == TRUE &&
		DoDetective == TRUE)
	{
		ReasoningDraw(back);
	}

	//�m�ؓxbox
	DrawBox(0, 0, back->MeterUpAmount, 30, Gold, TRUE);
	//�M���xbox
	DrawBox(0, 50, 300 - back->MeterDownAmount, 80, Gold, TRUE);

	MouseDraw();
}