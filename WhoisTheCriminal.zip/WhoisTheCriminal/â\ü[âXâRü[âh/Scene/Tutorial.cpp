#include "DxLib.h"
#include "Tutorial.h"
#include "math.h"

//���b�Z�[�W�{�b�N�X��X���W
#define MESSAGE_BOX_X_POS 250
//���b�Z�[�W�{�b�N�X��Y���W
#define MESSAGE_BOX_Y_POS 720

#define MenuMax 9
#define MaxVel 200

const int WIN_WIDTH = 1600; //�E�B���h�E����
const int WIN_HEIGHT = 900;//�E�B���h�E�c��

Tutorial::Tutorial()
{
	TutorialGr = LoadGraph("Materials/Tutorial/Gr/Background.png");
	BackNekoGr = LoadGraph("Materials/Tutorial/Gr/tatie_cat.png");
	Items[0] = LoadGraph("Materials/Tutorial/Gr/coffee.png");
	Items[1] = LoadGraph("Materials/Tutorial/Gr/ke.png");
	ReadFileItem1(this->TutorialItem1, 13);
	ReadFileItem2(this->TutorialItem2, 13);
	ReadFile(this->TutorialStory, 20);
	Flag = 0;

	for (int i = 0; i < ItemMax; i++)
	{
		ItemGet[i] = FALSE;
		ItemSet[i] = FALSE;
		ItemConfirmation[i] = FALSE;
	}
	for (int i = 0; i < MenuMax - 3; i++)
	{
		ItemsTrue[i] = 0;
	}
	TalkSet();
}

void Tutorial::TalkSet()
{
	for (int i = 0; i < 20; i++)
	{
		Charactor::DetectiveTalk[i] = -1;
		Charactor::NekokoTalk[i] = -1;
		Charactor::PoliceTalk[i] = -1;
	}
	Charactor::DetectiveTalk[0] = 2;
	Charactor::DetectiveTalk[1] = 4;
	Charactor::DetectiveTalk[2] = 6;
	Charactor::DetectiveTalk[3] = 7;
	Charactor::DetectiveTalk[4] = 10;
	Charactor::DetectiveTalk[5] = 12;
	Charactor::DetectiveTalk[6] = 15;
	Charactor::DetectiveTalk[7] = 17;
	Charactor::DetectiveTalk[8] = 19;
	Charactor::NekokoTalk[0] = 5;
	Charactor::NekokoTalk[1] = 9;
	Charactor::NekokoTalk[2] = 11;
	Charactor::NekokoTalk[3] = 16;
	Charactor::NekokoTalk[4] = 18;
	Charactor::PoliceTalk[0] = 3;
}

void Tutorial::ReadFileItem1(const char* FileName, int Max)
{
	FH = FileRead_open(FileName);

	for (int i = 0; i < Max; i++)
	{
		FileRead_gets(Item1Strings[i],
			sizeof(Item1Strings), FH);
	}

	FileRead_close(FH);
}

void Tutorial::ReadFileItem2(const char* FileName, int Max)
{
	FH = FileRead_open(FileName);

	for (int i = 0; i < Max; i++)
	{
		FileRead_gets(Item2Strings[i],
			sizeof(Item2Strings), FH);
	}

	FileRead_close(FH);
}

void Tutorial::Update(BackGround* back, Sounds* sound)
{
	sound->PlaySearchSounds();

	if (back->Initialize == TRUE)
	{
		Flag = 0;

		for (int i = 0; i < ItemMax; i++)
		{
			ItemGet[i] = FALSE;
			ItemSet[i] = FALSE;
			ItemConfirmation[i] = FALSE;
		}
		for (int i = 0; i < MenuMax - 3; i++)
		{
			ItemsTrue[i] = 0;
		}

		back->Initialize = FALSE;
	}

	MingTurn(back);

	GetMousePoint(&PosX, &PosY);

	if (ClickTimer >= 0)
	{
		ClickTimer--;
	}

	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
		ClickTimer <= 0)
	{
		ClickTimer = 30;

		//��b���i��
		if (Flag < 8 || Flag > 8 && Flag < 14 ||
			Flag > 14 && Flag < 19)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
		else if (Flag == 19)
		{
			back->OldScene = back->Scene;
			back->Scene = 4;
			back->Bright = 0;
		}

		//�l�R�R�ɘb��������
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			WIN_WIDTH - 100, WIN_HEIGHT - 100, WIN_WIDTH, WIN_HEIGHT) == 1
			&& Flag == 8)
		{
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}

		//�A�C�e�����莞(1)
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			840, 650, 900, 700) == 1 && ItemGet[0] == FALSE
			&& ItemSet[1] == FALSE && Flag == 14)
		{
			ItemSet[0] = TRUE;
		}

		//�A�C�e�����莞(2)
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			825, 535, 883, 560) == 1 && ItemGet[1] == FALSE
			&& ItemSet[0] == FALSE && Flag == 14)
		{
			ItemSet[1] = TRUE;
		}

		//���j���[���������Ƃ�
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			WIN_WIDTH - 70, 0, WIN_WIDTH, 70) == 1)
		{
			if (MenuFlag == FALSE)
			{
				MenuFlag = TRUE;
			}
			else if (MenuFlag == TRUE)
			{
				MenuFlag = FALSE;
			}
		}

		//�A�C�e�������ɐ������o���̌㏈��
		if (back->ItemVel >= MaxVel)
		{
			for (int i = 0; i < ItemMax; i++)
			{
				if (ItemSet[i] == TRUE)
				{
					ItemSet[i] = FALSE;
					ItemGet[i] = TRUE;
					ItemsTrue[i] = Items[i];
					back->ItemVel = 0;
				}

				if (ItemConfirmation[i] == TRUE)
				{
					ItemConfirmation[i] = FALSE;
					back->ItemVel = 0;
				}
			}
		}

		//���j���[�̂Ƃ�(�A�C�e���m�F��)
		if (MenuFlag == TRUE)
		{
			for (int i = 0; i < MenuMax; i++)
			{
				if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
					(int)MenuX[i], MenuY[i] + MenuYVel,
					(int)MenuX[i] + 70, MenuY[i] + 70 + MenuYVel) == 1 &&
					ItemGet[i] == TRUE && i < ItemMax)
				{
					MenuFlag = FALSE;
					ItemConfirmation[i] = TRUE;
				}
				else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
					(int)MenuX[i], MenuY[i] + MenuYVel,
					(int)MenuX[i] + 70, MenuY[i] + 70 + MenuYVel) == 1 &&
					i == 7)
				{
					back->OldScene = back->Scene;
					back->Scene = 6;
				}
				else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
					(int)MenuX[i], MenuY[i] + MenuYVel,
					(int)MenuX[i] + 70, MenuY[i] + 70 + MenuYVel) == 1 &&
					i == 8)
				{
					back->OldScene = back->Scene;
					back->Scene = 2;
				}
			}
		}

		if (ItemGet[0] == TRUE &&
			ItemGet[1] == TRUE &&
			Detective == FALSE)
		{
			if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				CenterX - 128, CenterY + 64, CenterX - 60, CenterY + 96) == 1)
			{
				DoDetective = TRUE;
				Detective = TRUE;
				Flag++;
				ChangeMessage(MainStrings[Flag]);
			}
			else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
				CenterX + 50, CenterY + 64, CenterX + 150, CenterY + 96) == 1)
			{
				DoDetective = FALSE;
				Detective = TRUE;
			}
		}

		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			0, WIN_HEIGHT - 32, 128, WIN_HEIGHT) == 1 &&
			DoDetective == FALSE &&
			Detective == TRUE)
		{
			DoDetective = TRUE;
			Detective = TRUE;
			Flag++;
			ChangeMessage(MainStrings[Flag]);
		}
	}

	if (ItemGet[0] == TRUE &&
		ItemGet[1] == TRUE &&
		Detective == FALSE)
	{
		ZoomUp(back);
	}

	//�A�C�e���m�F���ɍL������
	for (int i = 0; i < ItemMax; i++)
	{
		if (ItemSet[i] == TRUE ||
			ItemConfirmation[i] == TRUE)
		{
			ZoomUp(back);
		}
	}

	if (MenuFlag == FALSE)
	{
		EaseIn(back);
	}
	else if (MenuFlag == TRUE)
	{
		MenuYVel += GetMouseWheelRotVol() * 10;
		EaseOut(back);
	}
}

void Tutorial::BackDraw(BackGround* back)
{
	SetDrawBright(back->Bright, back->Bright, back->Bright);
	DrawGraph(0, 0, TutorialGr, TRUE);
	DrawExtendGraph(1500, 800, WIN_WIDTH, WIN_HEIGHT, BackNekoGr, TRUE);
	SetFontSize(32);

	if (Flag != 0 && Flag != 14)
	{
		DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS, TextBox[0], TRUE);
		if (Flag != 1 && Flag != 8 && Flag != 13)
		{
			DrawGraph(MESSAGE_BOX_X_POS, MESSAGE_BOX_Y_POS - 50, TextBox[1], TRUE);
		}
		drawMessage(White);
	}

	for (int i = 0; i < 20; i++)
	{
		if (DetectiveTalk[i] == Flag)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, DetectiveGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, back->name);
		}
		else if (NekokoTalk[i] == Flag)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, NekokoGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�l�R�R");
		}
		else if (PoliceTalk[i] == Flag)
		{
			DrawGraph(MESSAGE_BOX_X_POS - 200, MESSAGE_BOX_Y_POS - 60, PoliceGr, TRUE);
			DrawFormatString(MESSAGE_BOX_X_POS + 40, MESSAGE_BOX_Y_POS - 40,
				Chartreuse, "�x�@");
		}
	}

	if (Flag == 14)
	{
		DrawTriangle(WIN_WIDTH - 70, 20, WIN_WIDTH - 45, 70,
			WIN_WIDTH - 20, 20, Silver, TRUE);

		ItemDraw(ItemMax);
	}

	if (ItemSet[0] == TRUE)
	{
		DrawExtendGraph(CenterX - back->ItemVel * 3, CenterY - back->ItemVel,
			CenterX + back->ItemVel * 3, CenterY + back->ItemVel, FrameGr, TRUE);
		if (back->ItemVel >= MaxVel)
		{
			DrawFormatString(CenterX - back->ItemVel * 3 + 32, CenterY - back->ItemVel + 64, Gold,
				"%s", Item1Strings[0]);
			DrawGraph(CenterX - 32, CenterY, Items[0], TRUE);
		}
	}
	else if (ItemSet[1] == TRUE)
	{
		DrawExtendGraph(CenterX - back->ItemVel * 3, CenterY - back->ItemVel,
			CenterX + back->ItemVel * 3, CenterY + back->ItemVel, FrameGr, TRUE);
		if (back->ItemVel >= MaxVel)
		{
			DrawFormatString(CenterX - back->ItemVel * 3 + 32, CenterY - back->ItemVel + 64, Gold,
				"%s", Item2Strings[0]);
			DrawGraph(CenterX - 32, CenterY, Items[1], TRUE);
		}
	}

	if (ItemConfirmation[0] == TRUE)
	{
		DrawExtendGraph(CenterX - back->ItemVel * 3, CenterY - back->ItemVel,
			CenterX + back->ItemVel * 3, CenterY + back->ItemVel, FrameGr, TRUE);
		if (back->ItemVel >= MaxVel)
		{
			DrawFormatString(CenterX - back->ItemVel * 3 + 32, CenterY - back->ItemVel + 64, Gold,
				"%s\n%s\n%s", Item1Strings[1],Item1Strings[2], Item1Strings[3]);
			DrawGraph(CenterX - 32, CenterY, Items[0], TRUE);
		}
	}
	else if (ItemConfirmation[1] == TRUE)
	{
		DrawExtendGraph(CenterX - back->ItemVel * 3, CenterY - back->ItemVel,
			CenterX + back->ItemVel * 3, CenterY + back->ItemVel, FrameGr, TRUE);
		if (back->ItemVel >= MaxVel)
		{
			DrawFormatString(CenterX - back->ItemVel * 3 + 32, CenterY - back->ItemVel + 64, Gold,
				"%s\n%s",Item2Strings[3], Item2Strings[4]);
			DrawGraph(CenterX - 32, CenterY, Items[1], TRUE);
		}
	}

	if (ItemGet[0] == TRUE &&
		ItemGet[1] == TRUE &&
		Detective == FALSE)
	{
		DetectiveDraw(back);
	}

	if (DoDetective == FALSE &&
		Detective == TRUE)
	{
		DrawFormatString(0, WIN_HEIGHT - 32, Gold, "�����J�n");
	}

	MouseDraw();
}