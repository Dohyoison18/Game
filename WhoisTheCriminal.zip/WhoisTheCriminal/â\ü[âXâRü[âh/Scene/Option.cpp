#include "DxLib.h"
#include "Option.h"

Option::Option()
{
	TitleGr = LoadGraph("Materials/Title/Gr/title.png");
}

void Option::Update(BackGround* back, Sounds* sound)
{
	//sound->PlayTitleSounds();

	GetMousePoint(&PosX, &PosY);

	if (ClickTimer >= 0)
	{
		ClickTimer--;
	}

	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 && ClickTimer <= 0)
	{
		//BGMVolume / SEVolume / Back
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			510, 350, 560, 400) == 1)
		{
			if (sound->BGMVolume > 0)
			{
				sound->BGMVolume--;
				for (int i = 0; i < 6; i++)
				{
					ChangeVolumeSoundMem(sound->BGMVolume * 10, sound->BGM[i]);
				}
				ClickTimer = 20;
			}
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			1050, 350, 1100, 400) == 1)
		{
			if (sound->BGMVolume < 5)
			{
				sound->BGMVolume++;
				for (int i = 0; i < 6; i++)
				{
					ChangeVolumeSoundMem(sound->BGMVolume * 10, sound->BGM[i]);
				}
				ClickTimer = 20;
			}
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			510, 490, 560, 540) == 1)
		{
			if (sound->SEVolume > 0)
			{
				sound->SEVolume--;
				ChangeVolumeSoundMem(sound->SEVolume * 10, sound->SE);
				PlaySoundMem(sound->SE,DX_PLAYTYPE_BACK);
				ClickTimer = 20;
			}
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			1050, 490, 1100, 540) == 1)
		{
			if (sound->SEVolume < 5)
			{
				sound->SEVolume++;
				ChangeVolumeSoundMem(sound->SEVolume * 10, sound->SE);
				PlaySoundMem(sound->SE, DX_PLAYTYPE_BACK);
				ClickTimer = 20;
			}
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			758, 565, 918, 605) == 1)
		{
			//�O�񂪃��C���̏ꍇ�̓��C��,�^�C�g���̏ꍇ�̓^�C�g���ɖ߂�
			back->Scene = back->OldScene;
			ClickTimer = 20;
		}
	}
}

void Option::Draw(BackGround* back,Sounds* sound)
{
	DrawGraph(0, 0, TitleGr, TRUE);
	DrawExtendGraph(330, 185,
		1270, 715, FrameGr, TRUE);

	DrawTriangle(510, 375, 560, 350, 560, 400, Gold, TRUE);
	DrawTriangle(1050, 350, 1050, 400, 1100, 375, Gold, TRUE);
	DrawTriangle(510, 515, 560, 490, 560, 540, Gold, TRUE);
	DrawTriangle(1050, 490, 1050, 540, 1100, 515, Gold, TRUE);

	for (int i = 0; i < sound->BGMVolume; i++)
	{
		DrawExtendGraph(580 + i * 100, 350, 630 + i * 100, 400,
			back->MouseGr, TRUE);
	}

	for (int i = 0; i < sound->SEVolume; i++)
	{
		DrawExtendGraph(580 + i * 100, 490, 630 + i * 100, 540,
			back->MouseGr, TRUE);
	}

	//����
	DrawFormatString(768, 285, FrameColor, "BGM");
	DrawFormatString(780, 425, FrameColor, "SE");
	DrawFormatString(758, 565, FrameColor, "BACK");

	MouseDraw();
}