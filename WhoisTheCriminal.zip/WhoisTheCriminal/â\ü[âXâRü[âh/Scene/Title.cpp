#include "DxLib.h"
#include "Title.h"

Title::Title()
{
	TitleGr = LoadGraph("Materials/Title/Gr/title.png");
}

void Title::Update(BackGround* back, Sounds* sound)
{
	sound->PlayTitleSounds();

	GetMousePoint(&PosX, &PosY);

	if (ClickTimer >= 0)
	{
		ClickTimer--;
	}

	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
		ClickTimer <= 0)
	{
		ClickTimer = 20;
		if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			700, 600, 900, 640) == 1)
		{
			back->OldScene = back->Scene;
			//���O���͂�
			back->Scene = 1;
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			700, 665, 900, 705) == 1)
		{
			back->OldScene = back->Scene;
			//�I�v�V������
			back->Scene = 2;
		}
		else if (Collision(PosX - 5, PosY, PosX + 15, PosY + 23,
			700, 730, 900, 770) == 1)
		{
			DxLib_End();
		}
	}
}

void Title::BackDraw()
{
	//�w�i
	DrawGraph(0, 0, TitleGr, TRUE);

	SetFontSize(40);

	//�w�i�E�g�E�J�[�\��
	DrawExtendGraph(550, 535, 1020, 800, FrameGr, TRUE);

	//����
	DrawFormatString(700, 600, FrameColor, "START");
	DrawFormatString(700, 665, FrameColor, "OPTION");
	DrawFormatString(700, 730, FrameColor, "EXIT");
}

void Title::Draw()
{
	BackDraw();
	MouseDraw();
}