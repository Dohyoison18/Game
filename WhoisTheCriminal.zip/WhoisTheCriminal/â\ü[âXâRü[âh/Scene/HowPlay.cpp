#include "DxLib.h"
#include "HowPlay.h"

HowPlay::HowPlay()
{
	TitleGr = LoadGraph("Materials/Title/Gr/title.png");
	Gr = LoadGraph("Materials/AllUse/Gr/sousa.png");
}

void HowPlay::Click(BackGround* back)
{
	if (ClickTimer >= 0)
	{
		ClickTimer--;
	}

	if ((GetMouseInput() & MOUSE_INPUT_LEFT) != 0 &&
		ClickTimer <= 0)
	{
		ClickTimer = 30;
		back->Scene = back->OldScene;
	}
}

void HowPlay::Draw()
{
	DrawGraph(0, 0, TitleGr, TRUE);
	DrawGraph(200, 100, Gr, TRUE);
}